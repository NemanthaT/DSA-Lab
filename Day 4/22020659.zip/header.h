#ifndef header_h
#define header_h

typedef struct Node {
int data;
struct Node* next;
};

createNode(int data);
void insertAtBeginning(struct Node** headRef, int data);
void insertAtEnd(struct Node** headRef, int data);
void deleteNode(struct Node** headRef, int data);
void printLinkedList(struct Node* head);

#endif