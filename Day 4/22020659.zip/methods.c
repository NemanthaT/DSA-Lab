#include<stdio.h>
#include<stdlib.h>
#include "header.h"

createNode(int data){
    struct Node *nn;
    nn=malloc(sizeof(struct Node));
    nn->data=data;
    nn->next=NULL;
    return nn;
}
void printLinkedList(struct Node* head){
    int i=1;
    struct Node* nn;
    nn=head;
    while(nn->next!=NULL){
        printf("Data on Node %d: %d\n", i, nn->data);
        nn=nn->next;
        i++;
    }
}

void insertAtBeginning(struct Node** headRef, int data){
    struct Node *nn;
    nn=createNode(data);
    nn->next=*headRef;
    *headRef=nn;
}

void insertAtEnd(struct Node** headRef, int data){
    struct Node *nn;
    struct Node *tmp;
    nn=*headRef;
    while(nn->next!=NULL){
        nn=nn->next;
    }
    nn->data=data;
    tmp=createNode(data);
    nn->next=tmp;
}

void deleteNode(struct Node** headRef, int data){
    struct Node *nn;
    struct Node *tmp;
    struct Node *nxt;
    int i=1;
    nn=*headRef;
    while(nn->next!=NULL){
        if(data==1){
            tmp=nn->next;
            free(nn);
            *headRef=tmp;
        }
        if((data!=1)&&(i==(data-1))){
            tmp=nn->next->next;
            nxt=nn->next;
            free(nxt);
            nn->next=tmp;
        }
        nn=nn->next;
        i++;
    }
}